This is a bat file, if you don't want to break the game
don't edit the file
if you want to make some adjustments, no one's stopping you. Altough use caution
WARNING: this is just a beta version of the game
more will be coming soon